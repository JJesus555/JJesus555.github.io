document.addEventListener("DOMContentLoaded", () => {
    cargarTabla();


    document.getElementById("btnResetPassword").addEventListener("click", e => {
        e.preventDefault();
        const form = e.target.form;
        if (form.checkValidity()) {
            const newPassword = form.querySelector('#txtNewPassword').value.trim();
            restablecerContraseña(newPassword);
            cargarTabla();
            myModal.hide();
        } else {
            form.classList.add("was-validated");
        }
    });

    function restablecerContraseña(newPassword) {
        console.log("Contraseña restablecida:", newPassword);
    }


    const myModal = new bootstrap.Modal(document.getElementById('mdlUsuario'));
    const btnLimpiar = document.getElementById('btnLimpiar');
    
    document.getElementById("btnAgregar").addEventListener("click", () => {
        myModal.show();
        btnLimpiar.click();
    });

    document.getElementById("btnAceptar").addEventListener("click", e => {
        e.preventDefault();
        const form = e.target.form;
        if (form.checkValidity()) {
            const nombre = form.querySelector('#txtNombre').value.trim();
            const email = form.querySelector('#txtEmail').value.trim();
            if (!existeUsuario(email)) {
                agregarUsuario(nombre, email);
                cargarTabla();
                myModal.hide();
            } else {
                alert("El correo electrónico ya está registrado.");
            }
        } else {
            form.classList.add("was-validated");
        }
    });

    function existeUsuario(email) {
        const usuarios = JSON.parse(localStorage.getItem("listaUsuarios")) || [];
        return usuarios.some(usuario => usuario.correo === email);
    }

    function agregarUsuario(nombre, email) {
        const nuevoUsuario = {
            nombre: nombre,
            correo: email,
            telefono: ''  
        };
        let usuarios = JSON.parse(localStorage.getItem("listaUsuarios")) || [];
        usuarios.push(nuevoUsuario);
        localStorage.setItem("listaUsuarios", JSON.stringify(usuarios));
    }

    function cargarTabla() {
        inicializarDatos();
        const usuarios = JSON.parse(localStorage.getItem("listaUsuarios")) || [];
        const tbody = document.querySelector("#tblUsuarios tbody");
        tbody.innerHTML = "";  

        usuarios.forEach((usuario, index) => {
            const fila = document.createElement("tr");
            fila.innerHTML = `
                <td>${usuario.nombre}</td>
                <td>${usuario.correo}</td>
                <td>${usuario.telefono || ""}</td>
                <td><button class="btn btn-danger" onclick="eliminarUsuario(${index})">Eliminar</button></td>
            `;
            tbody.appendChild(fila);
        });
    }

    window.eliminarUsuario = function(index) {
        let usuarios = JSON.parse(localStorage.getItem("listaUsuarios"));
        usuarios.splice(index, 1);
        localStorage.setItem("listaUsuarios", JSON.stringify(usuarios));
        cargarTabla();
    };

    function inicializarDatos() {
        if (!localStorage.getItem("listaUsuarios")) {
            localStorage.setItem("listaUsuarios", JSON.stringify([]));
        }
    }
});
